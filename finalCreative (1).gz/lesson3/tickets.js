const express = require('express');
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));


app.use(express.static('public'));
const mongoose = require('mongoose');

// connect to the database
mongoose.connect('mongodb://localhost:27017/test', {
  useNewUrlParser: true
});

const ticketSchema = new mongoose.Schema({
  firstname: String,
  lastname:String,
  number: String,
  address: String, 
});

ticketSchema.set('toJSON', {
  virtuals: true
});

ticketSchema.virtual('id')
  .get(function() {
    return this._id.toHexString();
  });

const Ticket = mongoose.model('Ticket', ticketSchema);



app.use(express.static('public'));

app.get('/api/tickets', async (req, res) => {
  try {
    let tickets = await Ticket.find();
    res.send(tickets);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

app.post('/api/tickets', async (req, res) => {
    const ticket = new Ticket({
    firstname: req.body.firstname,
    lastname: req.body.lastname,
     number: req.body.number,
    address: req.body.address,
  });
  console.log(ticket);
  try {
    await ticket.save();
    res.send(ticket);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

app.delete('/api/tickets/:id', async(req, res) => {
  try {
    await Ticket.deleteOne({
      _id: req.params.id
    });
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

app.listen(3002, () => console.log('Server listening on port 3002!'));
