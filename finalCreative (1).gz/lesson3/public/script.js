var app = new Vue({
  el: '#app',
  data: {
    addedFirstName: '',
    addedLastName:'',
    addedNumber: '',
    addedAddress:'', 
    ticket: {},
  },
  created() {
    this.getInfo();
  },
  methods: {
    async getInfo() {
      try {
        let response = await axios.get("http://3.15.19.242:3002/api/tickets");
        this.tickets = response.data;
        console.log(this.tickets);
        return true;
      } catch (error) {
        console.log(error);
      }
    },
    async addInfo() {
      try {
        let response = await axios.post("http://3.15.19.242:3002/api/tickets", {
          firstname: this.addedFirstName,
          lastname: this.addedLastName,
          number: this.addedNumber, 
          address: this.addedAddress,
        });
        console.log("****number: " , this.addedNumber);
        this.addedFirstName = "";
        this.addedLastName = "";
        this.number = "";
        this.addedAddress="",
        this.getInfo();
        return true;
      } catch (error) {
        console.log(error);
      }
    },
    async deleteInfo(ticket) {
      try {
        let response = axios.delete("http://3.15.19.242:3002/api/tickets/" + ticket.id);
        this.getInfo();
        return true;
      } catch (error) {
        console.log(error);
      }
    }
  }
});